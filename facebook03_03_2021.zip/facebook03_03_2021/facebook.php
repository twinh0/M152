<?php
include("./header.inc.php");
//Initialisation des variables
$post = filter_input(INPUT_POST, 'postEcrit');
$submit = filter_input(INPUT_POST, 'submit');

//Taille des images
$taille_maxi = 3000000;
$taille = filesize($_FILES['image']['tmp_name']);

//Suppresion d'un media
$sup = filter_input(INPUT_GET, 'sup', FILTER_SANITIZE_STRING);

//Edition d'un media
$edit = filter_input(INPUT_GET, 'edit', FILTER_SANITIZE_STRING);

//Si on clique sur le boutton submit
if ($submit) {

	//Vérifie si le nom du media existe déjà
	foreach ($nomMedia as $n) {
		if ($n["nomMedia"] != $image) {
			$nomMediaDejaExistant = false;
		} else {
			$nomMediaDejaExistant = true;
		}
	}

	//POUR UPLOAD D'IMAGE
	//Nombre de fichiers totaux
	$total = count($_FILES['image']['tmp_name']);

	//Boucle pour tous les fichiers
	for ($i = 0; $i < $total; $i++) {
		//Image est égal au fichier selectionné dans le form
		$image = $_FILES['image']['name'][$i];

		if (substr($image, -3) == "png" || substr($image, -3) == "jpg" || substr($image, -3) == "PNG" || substr($image, -3) == "JPG" || substr($image, -3) == "peg" || substr($image, -3) == "PEG" || substr($image, -3) == "mp4" || substr($image, -3) == "MP4" || substr($image, -3) == "mp3" || substr($image, -3) == "mp3" && $taille > $taille_maxi) {
			//Définit le type du média 
			if (substr($image, -3) == "mp4" || substr($image, -3) == "MP4") {
				$typeMedia = "video";
			}
			if (substr($image, -3) == "mp3" || substr($image, -3) == "MP3") {
				$typeMedia = "audio";
			} else {
				$typeMedia = "image";
			}

			//Fichier image
			$uploaddir = './img/';

			$tmpFilePath = $_FILES['image']['tmp_name'][$i];

			//Si le fichier n'est pas vide
			if ($tmpFilePath != "") {

				// nom media genéré aléatoirement
				$nomMediaGenere = rand(0, 10000000) . rand(0, 10000000) . rand(0, 10000000) . $image;

				// Nouveau chemin
				$newFilePath = $uploaddir . $nomMediaGenere;;


				// Si tout marche, on prend le nom de l'image et on le met dans la bdd
				if (move_uploaded_file($tmpFilePath, $newFilePath) /*&& $nomMediaDejaExistant == false*/) {
					/* Démarre une transaction, désactivation de l'auto-commit */
					$bdd->beginTransaction();
					$insertImage->execute(array($typeMedia, $nomMediaGenere, date('Y-m-d H:i:s')));
					/* Valider les modifications */
					$bdd->commit();

					header("Location: facebook.php");
					die();
				}
			}
		} else {
			//Sinon, le média n'est pas accepté
			echo "Le média n'est pas accepté.";
			$bdd->rollBack();
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title>Facebook</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link href="assets/css/bootstrap.css" rel="stylesheet">
	<!--[if lt IE 9]>
          <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
	<link href="assets/css/facebook.css" rel="stylesheet">
</head>

<body>

	<div class="wrapper">
		<div class="box">
			<div class="row row-offcanvas row-offcanvas-left">

				<!-- main right col -->
				<div class="column col-sm-10 col-xs-11" id="main">

					<!-- top nav -->
					<div class="navbar navbar-blue navbar-static-top">
						<div class="navbar-header">
							<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a href="http://usebootstrap.com/theme/facebook" class="navbar-brand logo">b</a>
						</div>
						<nav class="collapse navbar-collapse" role="navigation">
							<form class="navbar-form navbar-left">
								<div class="input-group input-group-sm" style="max-width:360px;">
									<input class="form-control" placeholder="Search" name="srch-term" id="srch-term" type="text">
									<div class="input-group-btn">
										<button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
									</div>
								</div>
							</form>
							<ul class="nav navbar-nav">
								<li>
									<a href="facebook.php"><i class="glyphicon glyphicon-home"></i> Home</a>
								</li>
								<!--<li>
									<a href="#" role="button" data-toggle="modal"><i
											class="glyphicon glyphicon-plus"></i> Post</a>
								</li>-->
								<li>
									<a href="#postModal" role="button" data-toggle="modal"><i class="glyphicon glyphicon-upload"></i> Créer un post</a>
								</li>
								<li>
									<!--<a href="#"><span class="badge">badge</span></a>-->
								</li>
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-user"></i></a>
									<ul class="dropdown-menu">
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
									</ul>
								</li>
							</ul>
						</nav>
					</div>
					<!-- /top nav -->

					<div class="padding">
						<div class="full col-sm-9">

							<!-- content -->
							<div class="row">

								<!-- main col left -->
								<div class="col-sm-5">

									<div class="panel panel-default">
										<div class="panel-thumbnail"><img src="assets/img/bg_5.jpg" class="img-responsive"></div>
										<div class="panel-body">
											<p class="lead">gaming™</p>
											<p>1M Followers, 13 Posts</p>

											<p>
												<img src="assets/img/uFp_tsTJboUY7kue5XAsGAs28.png" height="28px" width="28px">
											</p>
										</div>
									</div>

								</div>

								<!-- main col right -->
								<div class="col-sm-7">

									<div class="well">
										<form class="form">
											<h4 style="text-align: center; font-size: 40px;">Welcome !</h4>
										</form>
									</div>

									<?php
									//Affiche les images envoyées
									foreach ($medias as $i) {

										//Btn suppression
										echo '<a style="margin:auto; color:red; background-color:pink; font-size:20px;" href="facebook.php?sup=' . $i["idMedia"] . '">-X-</a>';

										//Btn edition
										echo '<a style="margin:10px; color:blue; background-color:lightblue; font-size:20px;" href="facebook.php?edit=' . $i["idMedia"] . '">-E-</a>';
										if (file_exists('img/' . $i['nomMedia'])) {

											echo "<div class=\"panel panel-default\">";
											if ($i["typeMedia"] == "image") {
												echo "  <div class=\"panel-thumbnail\"><img src=\"./img/" . $i["nomMedia"] . "\" class=\"img-responsive\"></div>";
											} else if ($i["typeMedia"] == "video") {
												echo "  <div class=\"panel-thumbnail\"><video width='100%' controls autoplay muted loop><source src=\"./img/" . $i["nomMedia"] . "\"></video></div>";
											} else if ($i["typeMedia"] == "audio") {
												echo "  <div class=\"panel-thumbnail\"><audio width='100%' controls muted loop><source src=\"./img/" . $i["nomMedia"] . "\"></audio></div>";
											}
											echo "</div>";

											// Supprimer l'image								
											if ($sup == $i["idMedia"]) {
												unset($sup);
												unlink("./img/" . $i["nomMedia"]);
												$deleteImage->execute(array($i['idMedia']));
												header('Location: facebook.php');
												die();
											}
										}
									}
									?>

								</div>
							</div>
							<!--/row-->
							<div class="row">
								<div class="col-sm-6">
									<a href="#">Twitter</a> <small class="text-muted">|</small> <a href="#">Facebook</a>
									<small class="text-muted">|</small> <a href="#">Google+</a>
								</div>
							</div>

							<div class="row" id="footer">
								<div class="col-sm-6">

								</div>
								<div class="col-sm-6">
									<p>
										<a href="#" class="pull-right">Copyright 2021</a>
									</p>
								</div>
							</div>
							<hr>
							<h4 class="text-center">
								<a href="http://usebootstrap.com/theme/facebook" target="ext">Lien de la template
									@Bootply</a>
							</h4>
							<hr>


						</div><!-- /col-9 -->
					</div><!-- /padding -->
				</div>
				<!-- /main -->

			</div>
		</div>
	</div>


	<!--post modal-->
	<div id="postModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					Update Status
				</div>
				<div class="modal-body">
					<div class="form-group">
						<textarea class="form-control input-lg" autofocus="" placeholder="What do you want to share?"></textarea>
					</div>
				</div>

				<div class="modal-footer">
					<form action="facebook.php" method="post" enctype="multipart/form-data">
						<input type="file" multiple name="image[]" accept=".jpg,.jpeg,.png,.mp4" id="imageToUpload">
						<input type="submit" name="submit" />
						<div>
							<!-- <button class="btn btn-primary bt-sm" data-dismiss="modal" aria-hidden="true">Post</button>-->
							<ul class="pull-left list-inline">
								<!-- pour bouton icon <li><a href=""><i class="glyphicon glyphicon-upload"></i></a></li> 
							<li><a href=""><i class="glyphicon glyphicon-camera"></i></a></li>
							<li><a href=""><i class="glyphicon glyphicon-map-marker"></i></a></li>-->
							</ul>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript" src="assets/js/jquery.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('[data-toggle=offcanvas]').click(function() {
				$(this).toggleClass('visible-xs text-center');
				$(this).find('i').toggleClass('glyphicon-chevron-right glyphicon-chevron-left');
				$('.row-offcanvas').toggleClass('active');
				$('#lg-menu').toggleClass('hidden-xs').toggleClass('visible-xs');
				$('#xs-menu').toggleClass('visible-xs').toggleClass('hidden-xs');
				$('#btnShow').toggle();
			});
		});
	</script>
</body>

</html>