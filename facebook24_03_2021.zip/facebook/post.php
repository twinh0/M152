<?php
/*
 * N'hamoucha Mehdi
 * Site Facebook
 * Février-Mars 2021
 */

session_start();
require_once("./header.inc.php");

$edit = filter_input(INPUT_GET, 'edit', FILTER_SANITIZE_NUMBER_INT);

$_SESSION['namePrevImg'] = $_GET['nameImage'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
	<link href="assets/css/facebook.css" rel="stylesheet">
    <title>Edition</title>
</head>


<body>

	<div class="wrapper">
		<div class="box">
			<div class="row row-offcanvas row-offcanvas-left">

				<!-- main right col -->
				<div class="column col-sm-10 col-xs-11" id="main">

					<!-- top nav -->
					<div class="navbar navbar-blue navbar-static-top">
						<div class="navbar-header">
							<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a href="http://usebootstrap.com/theme/facebook" class="navbar-brand logo">b</a>
						</div>
						<nav class="collapse navbar-collapse" role="navigation">
							<form class="navbar-form navbar-left">
								<div class="input-group input-group-sm" style="max-width:360px;">
									<input class="form-control" placeholder="Search" name="srch-term" id="srch-term" type="text">
									<div class="input-group-btn">
										<button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
									</div>
								</div>
							</form>
							<ul class="nav navbar-nav">
								<li>
									<a href="facebook.php"><i class="glyphicon glyphicon-home"></i> Home</a>
								</li>
								<li>
									<a href="post.php" role="button"><i class="glyphicon glyphicon-plus"></i> Post</a>
								</li>
								<li>
									<a href="#"><span class="badge">badge</span></a>
								</li>
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-user"></i></a>
									<ul class="dropdown-menu">
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
										<li><a href="">More</a></li>
									</ul>
								</li>
							</ul>
						</nav>
					</div>
					<!-- /top nav -->


					<!-- content -->
					<div class="row">

						<!-- main col right -->
						<div class="col-sm-7" style="visibility:hidden;">

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4><?= $edit == null ? "Write something here" : "Update your post"?></h4>
								</div>
							</div>

						</div>

						<!-- main col left -->
						<div class="col-sm-5">

							<div class="well">
									<h4><?= $edit == null ? "What's New" : "Update this post" ?></h4>

									<form action="facebook.php" method="POST" enctype="multipart/form-data">
										<div hidden class="form-group" style="padding:14px;">
											<textarea class="form-control" name="postEcrit" placeholder="<?= $edit == null ? "Write something here" : "Update your post"?>"></textarea>
										</div>

										<ul class="list-inline">
											<input type="file" name="image[]" class="form-control-file" id="img" accept=".jpg,.jpeg,.png,.gif,.bmp,.mp3,.mp4"/>
										</ul>
										<input type="submit" name="submit" value="<?= $edit == null ? "Post" : "Update" ?>" class="btn btn-primary pull-right" />
										
										<input type="text" name="replaceMedia" value="<?= $edit == null ? "" : $edit ?>"/>
										<input type="text" name="nomReplaceMedia" value="<?= $edit == null ? "" : $_SESSION['namePrevImg']?>"/>
									</form>

							</div>

						</div>
					</div>

					<!-- /main -->

				</div>
			</div>
		</div>

		<script type="text/javascript" src="assets/js/jquery.js"></script>
		<script type="text/javascript" src="assets/js/bootstrap.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$('[data-toggle=offcanvas]').click(function() {
					$(this).toggleClass('visible-xs text-center');
					$(this).find('i').toggleClass('glyphicon-chevron-right glyphicon-chevron-left');
					$('.row-offcanvas').toggleClass('active');
					$('#lg-menu').toggleClass('hidden-xs').toggleClass('visible-xs');
					$('#xs-menu').toggleClass('visible-xs').toggleClass('hidden-xs');
					$('#btnShow').toggle();
				});
			});
		</script>
</body>
</html>